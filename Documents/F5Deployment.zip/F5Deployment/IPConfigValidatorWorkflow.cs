﻿// ---------------------------------------------------------------------------
// <copyright file="IPConfigValidatorWorkflow.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
// ---------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Microsoft.Office.Datacenter.Networking.EopWorkflows.F5Deployment
{
    #region Local Usings

    using Microsoft.Office.Datacenter.CentralAdmin.Interop;
    using Microsoft.Office.Datacenter.CentralAdmin.Workflow.Framework;
    using Microsoft.Office.Datacenter.Networking.KustoFactory;
    using Microsoft.Office.Datacenter.Networking.Workflows.Shared.Email;
    using Microsoft.Office.Datacenter.Networking.Workflows.Shared.Extensions;
    using Microsoft.Office.Datacenter.Networking.Workflows.Shared.ProxyRoles;
    using StringList = List<string>;
    using StringListMap = Dictionary<string, List<string>>;
    using StringMap = Dictionary<string, string>;

    #endregion

    [ProxyScript("Invoke-IPConfigValidatorWorkflow.ps1",
        typeof(NetworkingChangeAccessScriptsRole),
        typeof(EopManagementChangeAccessScriptsRole))]
    public sealed class IPConfigValidatorWorkflow : Workflow<IPConfigValidatorWorkflow.ValidationRecordList>
    {
        #region Inner Classes

        public interface IUnitTestService
        {
            Assembly TestAssembly { get; }
        }

        public enum ValidationStatus
        {
            Unknown,
            Success,
            NoMatch,            // No matching record found in Kusto
            MultipleMatches,    // A specific IP has multiple prefixes
            WrongAddressSpace,  // In wrong addressspace
            Obsolete,           // Should be removed in config
            NoMappingDcName,    // EOP datacenter name has no mapping Azure name
            EmptyTitle,
            EmptyDatacenter,
            EmptyRegion,
            MismatchedDcName,   // Azure name does not match EOP name
            InvalidTitle,       // No datacenter/forest name in title
            InvalidRegion,
            DubiousTitle,       // Title has dubious words
        }

        [DataContract]
        public class ValidationRecord
        {
            public static readonly ValidationRecord NoMatch = new ValidationRecord(ValidationStatus.NoMatch);
            public static readonly ValidationRecord Success = new ValidationRecord(ValidationStatus.Success);

            [DataMember]
            public string Id;

            [DataMember]
            public string AddressSpace;

            [DataMember]
            public string IpString;

            [DataMember]
            public string Prefix;

            [DataMember]
            public string Environment;  // Forest-DC

            [DataMember]
            public string Forest;       // Forest name in _environments.xml

            [DataMember]
            public string EopDcName;    // EOP datacenter name obtained from config name

            [DataMember]
            public string IpamDcName;   // Name in IPAM

            [DataMember]
            public string Region;

            [DataMember]
            public string Title;

            [DataMember]
            public string Summary;

            [DataMember]
            public ValidationStatus Status;

            public ValidationRecord(ValidationStatus status, string summary = null)
            {
                this.Status = status;
                this.Summary = summary;
            }
        }

        [CollectionDataContract]
        public class ValidationRecordList : List<ValidationRecord>
        {
        }

        #endregion

        #region Constants

        private static readonly char[] FieldSeparatorChars = new[] { ',', ' ' };

        #endregion

        #region Workflow Parameters

        [DataMember(IsRequired = false)]
        public string RecipientEmailAddresses { get; set; } = "v-chunly@microsoft.com";

        [DataMember(IsRequired = false)]
        public bool ShouldSendEmailNotfication { get; set; } = true;

        #endregion

        #region Cached Variables

        IWorkflowRuntime runtime;

        #endregion

        #region Private Variables

        // Contains IP strings that are already in processing.
        private List<string> ipHotList = new List<string>();

        // Contains IP prefix IDs that are already analyzed.
        private List<string> prefixIdList = new List<string>();

        private StringMap dcNameMap = new StringMap();
        private StringMap suffixNameMap = new StringMap();
        private StringMap forestNameMap = new StringMap();
        private StringMap envSpaceMap = new StringMap();
        private StringMap dcNameExceptionMap = new StringMap();
        private StringListMap forestAliasMap = new StringListMap();
        private StringListMap azureNameMap = new StringListMap();
        private Dictionary<string, StringMap> regionMaps = new Dictionary<string, StringMap>();
        private Dictionary<string, Regex> dubiousTitlePatterns = new Dictionary<string, Regex>();
        private StringList ipStringExclusionList = new StringList();
        private StringList dubiousTitleWords = new StringList();

        private const string IpamDatabaseName = "IpamReport";
        private const string IpamKustoServerEndpoint = "https://ipam.kusto.windows.net";
        public const string QueryFileName = "Files.KustoIPQuery.txt";

        public static readonly string[] KustoDataTableNames = new[]
        {
            "Allocations_Default",
            "Allocations_Galacake",
            "Allocations_EX",
            "Allocations_RX"
        };

        public static readonly string[] KustoTagTableNames = new[]
        {
            "Tags_Default",
            "Tags_Galacake",
            "Tags_EX",
            "Tags_RX"
        };

        private string queryTemplate;
        private ICslQueryProvider kustoClient;

        #endregion

        #region DoWork Override

        private ValidationRecordList output;

        public override ValidationRecordList Output => output;

        protected override Continuation DoWork(IWorkflowRuntime runtime)
        {
            this.runtime = runtime;

            PrepareKusto();
            LoadNameMap();
            DoWorkAsync().Wait();
            SendEmailNotification();

            return Continuation.Default;
        }

        /// <summary>
        /// Does actual work.
        /// </summary>
        /// <returns>An async task.</returns>
        private async Task DoWorkAsync()
        {
            var testService = runtime.HostServices.GetService (typeof(IUnitTestService)) as IUnitTestService;
            var targetAsm = testService == null ? this.GetType().Assembly : testService.TestAssembly;
            var rcNames = targetAsm.GetManifestResourceNames();
            var myType = this.GetType();

            // Always load _environments.xml in this assembly.
            LoadForestMap(myType.Assembly, $"{myType.Namespace}.Config._environments.xml");

            if (forestNameMap.Count == 0)
            {
                throw new Exception("No _environments.xml resource found!");
            }

            var finder = new IPTagFinder();

            output = new ValidationRecordList();

            foreach (var rcName in rcNames)
            {
                // Only look for XML files
                if (!rcName.EndsWithText(".xml")) { continue; }

                // Skip special files
                if (rcName.StartsWith("_")) { continue; }

                var rcXml = targetAsm.LoadResourceText(rcName);
                var ipXDoc = finder.Find(rcXml);
                var envName = ExtractEnvironmentName(rcName);
                var eopDcName = ExtractDcName(envName);
                var forestName = GetForestName(envName);

                if (forestName == null)
                {
                    runtime.Logger.LogInformation($"***Config name {rcName} has no mapped forest name.");
                    forestName = ExtractForestName(envName);
                    if (forestName == null)
                    {
                        runtime.Logger.LogError($"***Config name {rcName} has no forest name.");
                        continue;
                    }
                }
                if (eopDcName == null)
                {
                    runtime.Logger.LogError($"***Config name {rcName} has no datacenter name.");
                    continue;
                }
                else
                {
                    var azureName = GetAzureDcName(eopDcName);
                    if (azureName == null)
                    {
                        runtime.Logger.LogError($"EOP datacenter {eopDcName} has no Azure name");
                    }
                }

                foreach (var node in ipXDoc.Root.Elements())
                {
                    foreach (var attr in node.Attributes())
                    {
                        if (attr.Value.IndexOfAny(FieldSeparatorChars) >= 0)
                        {
                            var a = attr.Value.SplitWithoutEmpty(FieldSeparatorChars);
                            foreach (var ipString in a)
                            {
                                await ProcessIpString(forestName, eopDcName, ipString);
                            }
                        }
                        else
                        {
                            await ProcessIpString(forestName, eopDcName, attr.Value);
                        }
                    }
                }
            }
        }

        private void PrepareKusto()
        {
            if (kustoClient == null)
            {
                kustoClient =
                    runtime.HostServices.GetService(typeof(ICslQueryProvider))
                    as ICslQueryProvider ??
                    NetworkingKustoClientFactory.GetCslQueryProvider(
                        kustoDatabase: IpamDatabaseName,
                        kustoServer: IpamKustoServerEndpoint);
            }
            if (queryTemplate == null)
            {
                var myType = GetType();

                queryTemplate = myType.Assembly.LoadResourceText($"{myType.Namespace}.{QueryFileName}");
            }

            foreach (var tableName in KustoTagTableNames)
            {
                var regionMap = new StringMap();
                var query = $"OrbGetTabImplyMapping('{tableName}') | where source == 'Datacenter'and dest == 'Region'";
                var queryReader = kustoClient.ExecuteQueryAsync(query).Result;

                while (queryReader.Read())
                {
                    var datacenter = queryReader["sourceValue"] as string;
                    var region = queryReader["destValue"] as string;
                    regionMap[datacenter] = region;
                }
                regionMaps[tableName] = regionMap;
            }
        }

        /// <summary>
        /// Processes a single IP string (specific or prefix).
        /// </summary>
        /// <param name="forestName">Forest name in config.</param>
        /// <param name="eopDcName">EOP datacenter name in config.</param>
        /// <param name="ipString">IP string.</param>
        /// <returns>An async task.</returns>
        private async Task ProcessIpString(string forestName, string eopDcName, string ipString)
        {
            // A valid IPv6 string must have at least 5 groups.
            if (ipString.Contains(':') &&
                !ipString.EndsWith("::") &&
                ipString.Count((c) => c == ':') <= 4) { return; }

            lock (ipHotList)
            {
                if (ipHotList.Contains(ipString)) { return; }
                ipHotList.Add(ipString);
            }

            var hasAnyMatch = false;
            var envName = $"{forestName}-{eopDcName}";

            foreach (var tableName in KustoDataTableNames)
            {
                try
                {
                    var record = await ValidateIPOnKusto(tableName, forestName, eopDcName, ipString);
                    if (record.Status == ValidationStatus.NoMatch) { continue; }
                    if (record.Status == ValidationStatus.Unknown)
                    {
                        runtime.Logger.LogError("Program logic error, got Unknown status!");
                        continue;
                    }

                    hasAnyMatch = true;

                    /*
                    * If the IP string has a parent prefix in this address space,
                    * then check if its environment should really be in it.
                    *
                    * */

                    if (record.Status != ValidationStatus.MultipleMatches &&
                        record != ValidationRecord.Success)
                    {
                        var mappedSpaceName = GetEnvSpaceName(envName) ?? "Default";

                        if (!tableName.IsSameTextAs(mappedSpaceName))
                        {
                            var wrongSpaceRecord = new ValidationRecord(
                                ValidationStatus.WrongAddressSpace,
                                $"Should be in address space {mappedSpaceName}")
                            {
                                Id = record.Id,
                                AddressSpace = record.AddressSpace,
                                Environment = record.Environment,
                                Forest = record.Forest,
                                EopDcName = record.EopDcName,
                                Prefix = record.Prefix,
                                IpString = ipString,
                                IpamDcName = record.IpamDcName,
                                Region = record.Region,
                                Title = record.Title,
                            };
                            DumpValidationRecord(wrongSpaceRecord);
                        }
                    }

                    // The following properties are not set in ValidateIpString.
                    record.Environment = envName;

                    if (record.Status != ValidationStatus.Success &&
                        record.Status != ValidationStatus.MultipleMatches)
                    {
                        output.Add(record);
                        DumpValidationRecord(record);
                    }
                }
                catch (Exception ex)
                {
                    runtime.Logger.LogError($@"!!!Got exception!!!
                        Kusto Table: {tableName}
                        Environment: {envName}
                        IP string:   {ipString}
                        Exception:   {ex}");
                }
            }

            if (!hasAnyMatch)
            {
                var noMatchRecord = new ValidationRecord(ValidationStatus.NoMatch)
                {
                    Forest = forestName,
                    EopDcName = eopDcName,
                    Environment = envName,
                    IpString = ipString,
                };
                DumpValidationRecord(noMatchRecord);
            }
        }

        private void DumpValidationRecord(ValidationRecord record)
        {
            runtime.Logger.LogWarning($@"===Validation record===
                            Kusto Table: {record.AddressSpace}
                            Environment: {record.Environment}
                            IP string:   {record.IpString}
                            Prefix:      {record.Prefix}
                            Datacenter:  {record.IpamDcName}
                            Region:      {record.Region}
                            Status:      {record.Status}
                            Summary:     {record.Summary}
                            Title:       {record.Title}");
        }

        #endregion

        #region Load Name Map

        /// <summary>
        /// Loads environment and forest name mappings in _environments.xml.
        /// </summary>
        /// <param name="asm">Target assembly that contains the embedded resource file.</param>
        /// <param name="rcName">Resource name of _environments.xml.</param>
        private void LoadForestMap(Assembly asm, string rcName)
        {
            using (var rcs = asm.GetManifestResourceStream(rcName))
            {
                var envDoc = XDocument.Load(rcs);

                foreach (var node in envDoc.Root.Elements("object"))
                {
                    var envName = node.Attribute("environment-name").Value;
                    if (!envName.StartsWith("_"))
                    {
                        var forestName = node.Attribute("forest-name").Value;
                        forestNameMap[envName.ToUpper()] = forestName;
                    }
                }
            }
        }

        /// <summary>
        /// Loads datacenter name mappings from embedded XML file.
        /// </summary>
        private void LoadNameMap()
        {
            var myType = this.GetType();
            var rcName = myType.Namespace + ".Files.NameMap.xml";
            using (var rcs = myType.Assembly.GetManifestResourceStream(rcName))
            {
                var mapDoc = XDocument.Load(rcs);

                foreach (var node in mapDoc.Root.Element("DCNames").Elements())
                {
                    var eopName = node.Attribute("EOPName").Value;
                    var azureName = node.Attribute("AzureName").Value;
                    dcNameMap[eopName] = azureName;
                }

                foreach (var node in mapDoc.Root.Element("ForestAliases").Elements())
                {
                    var forestName = node.Attribute("ForestName").Value;
                    var aliases = node.Attribute("Aliases").Value;
                    forestAliasMap[forestName] = aliases.SplitWithoutEmpty(FieldSeparatorChars).ToList();
                }

                foreach (var node in mapDoc.Root.Element("DCSuffixes").Elements())
                {
                    var suffix = node.Attribute("Text").Value;
                    var forestNames = node.Attribute("ForestNames").Value;
                    foreach (var forestName in forestNames.SplitWithoutEmpty(','))
                    {
                        suffixNameMap[forestName] = suffix;
                    }
                }

                foreach (var node in mapDoc.Root.Element("EnvironmentSpaces").Elements())
                {
                    var spaceName = node.Attribute("SpaceName").Value;
                    var envNames = node.Attribute("EnvironmentNames").Value;
                    foreach (var envName in envNames.SplitWithoutEmpty(','))
                    {
                        envSpaceMap[envName] = spaceName;
                    }
                }

                foreach (var node in mapDoc.Root.Element("DCNameExceptions").Elements())
                {
                    var envName = node.Attribute("Environment").Value;
                    var dcName = node.Attribute("AzureDCName").Value;
                    dcNameExceptionMap[envName] = dcName;
                }

                foreach (var node in mapDoc.Root.Element("ExclusionList").Elements())
                {
                    var values = node.Attribute("StartsWith").Value;
                    foreach (var value in values.SplitWithoutEmpty(','))
                    {
                        ipStringExclusionList.Add(value);
                    }
                }

                foreach (var node in mapDoc.Root.Element("TitleWordingIssues").Elements())
                {
                    if (node.Name == "Contains")
                    {
                        dubiousTitleWords.Add(node.Attribute("Text").Value);
                    }
                    else if (node.Name == "Pattern")
                    {
                        var text = node.Attribute("Text").Value;
                        dubiousTitlePatterns[text] = new Regex(
                            text,
                            RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Singleline);
                    }
                    else
                    {
                        runtime.Logger.LogWarning($"Invalid node name {node.Name} in TitleWordingIssues");
                    }
                }
            }

            /*
             * Build reverse Azure name map out of datacenter name map.
             *
             * EOP to Azure mapping is one/many to one, but Azure to EOP is one to many.
             *
             * */

            foreach (var entry in dcNameMap)
            {
                if (!azureNameMap.TryGetValue(entry.Value, out var list))
                {
                    list = new StringList();
                    azureNameMap[entry.Value] = list;
                }
                list.Add(entry.Key);
            }
        }

        private string GetAzureDcName(string eopName)
        {
            if (dcNameMap.TryGetValue(eopName.ToUpper(), out var name))
            { return name; }
            return null;
        }

        private StringList GetForestAliases(string forestName)
        {
            if (forestAliasMap.TryGetValue(forestName.ToUpper(), out var list))
            { return list; }
            return null;
        }

        private string GetDcSuffix(string forestName)
        {
            if (suffixNameMap.TryGetValue(forestName.ToUpper(), out var suffix))
            { return suffix; }
            return null;
        }

        private string GetForestName(string envName)
        {
            if (forestNameMap.TryGetValue(envName.ToUpper(), out var name))
            { return name; }
            return null;
        }

        /// <summary>
        /// Extracts environment name from resource name like "abc.def.name.xml".
        /// </summary>
        /// <param name="rcName">Resource name.</param>
        /// <returns>Environment name.</returns>
        private string ExtractEnvironmentName(string rcName)
        {
            var dotIndex1 = rcName.LastIndexOf('.');
            if (dotIndex1 > 0)
            {
                var dotIndex2 = rcName.LastIndexOf('.', dotIndex1 - 1) + 1;
                return rcName.Substring(dotIndex2, dotIndex1 - dotIndex2);
            }
            return rcName;
        }

        private string ExtractForestName(string envName)
        {
            var index = envName.LastIndexOf('-');
            if (index > 0) { return envName.Substring(0, index); }
            return null;
        }

        private string ExtractDcName(string envName)
        {
            var index = envName.LastIndexOf('-');
            if (index > 0) { return envName.Substring(index + 1); }
            return null;
        }

        private string GetEnvSpaceName(string envName)
        {
            if (envSpaceMap.TryGetValue(envName.ToUpper(), out var name))
            { return name; }
            return null;
        }

        private string GetDcExceptionName(string envName)
        {
            if (dcNameExceptionMap.TryGetValue(envName.ToUpper(), out var dcExName))
            { return dcExName; }
            return null;
        }

        private StringList GetEopNames(string azureName)
        {
            if (azureNameMap.TryGetValue(azureName.ToUpper(), out var list))
            { return list; }
            return null;
        }

        #endregion

        #region Kusto Query

        /// <summary>
        /// Queries against Kusto to verify if an IP string is in use.
        /// </summary>
        /// <param name="kustoTableName">Kusto table name.</param>
        /// <param name="forestName">Forest name in config.</param>
        /// <param name="eopDcName">EOP datacenter name in config.</param>
        /// <param name="ipString">IP string.</param>
        /// <returns>A ValidationRecord object.</returns>
        private async Task<ValidationRecord> ValidateIPOnKusto(
            string kustoTableName,
            string forestName,
            string eopDcName,
            string ipString)
        {
            var envName = $"{forestName}-{eopDcName}".ToUpper();
            var requestProperties = KustoClientExtensions
                .GetClientRequestPropertiesForApplication(runtime, "IPConfigValidatorWorkflow");
            var ipVersion = ipString.Contains(':') ? "6" : "4";
            var query = queryTemplate
                .Replace("{TableName}", kustoTableName)
                .Replace("{IpVersion}", ipVersion)
                .Replace("{IpString}", ipString);
            var queryReader = await kustoClient.ExecuteQueryAsync(query, requestProperties);

            if (queryReader.RecordsAffected > 1)
            {
                var summaryBuilder = new StringBuilder();

                while (queryReader.Read())
                {
                    var prefix = queryReader["Prefix"] as string;
                    var allocRegion = queryReader["Region"] as string;
                    var network = queryReader["PhysicalNetwork"] as string;
                    var propertyGroup = queryReader["PropertyGroup"] as string;

                    summaryBuilder.AppendFormat(
                        "Prefix: {0}, Region: {1}, Physical Network: {2}, Property Group: {3}",
                        prefix,
                        allocRegion,
                        network,
                        propertyGroup);
                    summaryBuilder.AppendLine();
                }

                return new ValidationRecord(ValidationStatus.MultipleMatches, summaryBuilder.ToString())
                {
                    AddressSpace = kustoTableName,
                    Forest = forestName,
                    EopDcName = eopDcName,
                    Environment = envName,
                    IpString = ipString,
                };
            }

            if (queryReader.Read())
            {
                var prefixId = queryReader["Id"] as string;
                lock (prefixIdList)
                {
                    if (prefixIdList.Contains(prefixId)) { return ValidationRecord.Success; }
                    prefixIdList.Add(prefixId);
                }

                var title = queryReader["Title"] as string;
                var ipamDcName = queryReader["Datacenter"] as string;
                var prefix = queryReader["Prefix"] as string;
                var region = queryReader["Region"] as string;
                var validationRecord = new ValidationRecord(ValidationStatus.Unknown)
                {
                    Id = prefixId,
                    AddressSpace = kustoTableName,
                    Forest = forestName,
                    EopDcName = eopDcName,
                    Prefix = prefix,
                    IpString = ipString,
                    IpamDcName = ipamDcName,
                    Region = region,
                    Title = title,
                };

                /*
                * Skip large blocks
                *
                * */

                var isIPv6 = prefix.Contains(':');
                var prefixNumber = int.Parse(prefix.Substring(prefix.LastIndexOf('/') + 1));

                if (isIPv6)
                {
                    if (prefixNumber < 64)
                    {
                        validationRecord.Status = ValidationStatus.Success;
                        validationRecord.Summary = "Large block";
                        return validationRecord;
                    }
                }
                else
                {
                    if (prefixNumber < 23)
                    {
                        validationRecord.Status = ValidationStatus.Success;
                        validationRecord.Summary = "Large block";
                        return validationRecord;
                    }
                }

                if (string.IsNullOrWhiteSpace(ipamDcName))
                {
                    validationRecord.Status = ValidationStatus.EmptyDatacenter;
                    validationRecord.Summary = "Datacenter should not be empty";
                    return validationRecord;
                }

                if (string.IsNullOrWhiteSpace(title))
                {
                    if (!isIPv6 && prefixNumber == 32)
                    {
                        validationRecord.Status = ValidationStatus.Obsolete;
                        validationRecord.Summary = "Should be deleted";
                        return validationRecord;
                    }

                    validationRecord.Status = ValidationStatus.EmptyTitle;
                    validationRecord.Summary = "Title should not be empty";
                    return validationRecord;
                }

                var azureDcName = GetAzureDcName(eopDcName);
                var suffix = GetDcSuffix(forestName);
                string normalizedDcName = ipamDcName.EndsWithText(suffix)
                    ?
                    ipamDcName.Substring(0, ipamDcName.Length - suffix.Length)
                    :
                    null;

                if (!(
                    ipamDcName.IsSameTextAs(eopDcName) ||
                    ipamDcName.IsSameTextAs(azureDcName) ||
                    normalizedDcName.IsSameTextAs(eopDcName) ||
                    normalizedDcName.IsSameTextAs(azureDcName)
                    ))
                {
                    // If not, check if this environment has an exception datacenter name.
                    var dcExName = GetDcExceptionName(envName);

                    if (!ipamDcName.IsSameTextAs(dcExName))
                    {
                        validationRecord.Status = ValidationStatus.MismatchedDcName;
                        validationRecord.Summary = azureDcName == null || azureDcName.IsSameTextAs(eopDcName)
                            ?
                            $"Datacenter {ipamDcName} does not match EOP name {eopDcName}"
                            :
                            $"Datacenter {ipamDcName} does not match EOP name {eopDcName} or mapped Azure name {azureDcName}";
                        return validationRecord;
                    }
                }

                /*
                 * Build a map that contains 4 possible names: IPAM, EOP, Azure and
                 * normalized. This will greatly simplify name checking by flattening
                 * nested if-else blocks to a simple loop.
                 *
                 * */

                var dcNameMap = new StringMap();
                Func<string, bool?> dcNameMapcontains = (name_) =>
                {
                    if (string.IsNullOrEmpty(name_)) { return null; }
                    return dcNameMap.Values.Any((dcName_) => dcName_.IsSameTextAs(name_));
                };

                dcNameMap["datacenter"] = ipamDcName;
                if (dcNameMapcontains(eopDcName) == false)
                {
                    dcNameMap["EOP"] = eopDcName;
                }
                if (dcNameMapcontains(azureDcName) == false)
                {
                    dcNameMap["mapped Azure"] = azureDcName;
                }
                if (dcNameMapcontains(normalizedDcName) == false)
                {
                    dcNameMap["normalized"] = normalizedDcName;
                }

                if (string.IsNullOrEmpty(region))
                {
                    validationRecord.Status = ValidationStatus.EmptyRegion;
                    validationRecord.Summary = "Region is empty";
                    return validationRecord;
                }
                else
                {
                    var regionMap = regionMaps[kustoTableName];
                    string mappedRegion = null;

                    // Find mapped region in region map.
                    foreach (var regionEntry in regionMap)
                    {
                        if (ipamDcName.IsSameTextAs(regionEntry.Key))
                        {
                            mappedRegion = regionEntry.Value;
                            break;
                        }
                    }

                    if (!region.IsSameTextAs(mappedRegion))
                    {
                        validationRecord.Status = ValidationStatus.InvalidRegion;
                        validationRecord.Summary = $"Region does not match implied region ({mappedRegion ?? "<none>"})";
                        return validationRecord;
                    }
                }

                // Check if title contains datacenter name.
                var containsDcName = false;
                foreach (var entry in dcNameMap)
                {
                    if (title.ContainsText(entry.Value))
                    {
                        containsDcName = true;
                        break;
                    }
                }

                if (!containsDcName)
                {
                    /*
                     * Not sure if this is helpful, but I do observe some prefix
                     * titles contain a "reversed" EOP name (not the one in config).
                     *
                     * */

                    var dcNameList = GetEopNames(ipamDcName);
                    if (dcNameList != null)
                    {
                        foreach (var name in dcNameList)
                        {
                            if (title.ContainsText(name))
                            {
                                containsDcName = true;
                                break;
                            }
                        }
                    }

                    if (!containsDcName)
                    {
                        // It's a little tricky to get a useful description...
                        var summaryBuilder = new StringBuilder();
                        summaryBuilder.AppendFormat("Title does not contain datacenter name {0}", ipamDcName);
                        foreach (var entry in dcNameMap)
                        {
                            if (entry.Key != "datacenter")
                            {
                                summaryBuilder.AppendFormat(" or {0} name {1}", entry.Key, entry.Value);
                            }
                        }

                        validationRecord.Status = ValidationStatus.InvalidTitle;
                        validationRecord.Summary = summaryBuilder.ToString();
                        return validationRecord;
                    }
                }

                if (!title.ContainsText(forestName))
                {
                    var containsAlias = false;
                    var aliasList = GetForestAliases(forestName);

                    if (aliasList?.Count > 0)
                    {
                        foreach (var forestAlias in aliasList)
                        {
                            if (title.ContainsText(forestAlias))
                            {
                                containsAlias = true;
                                break;
                            }
                        }
                    }

                    if (!containsAlias)
                    {
                        validationRecord.Status = ValidationStatus.InvalidTitle;
                        validationRecord.Summary = aliasList?.Count > 0
                            ?
                            $"Title does not contain forest name ({forestName} or any of aliases ({string.Join(",", aliasList)})"
                            :
                            $"Title does not contain forest name ({forestName})";
                        return validationRecord;
                    }
                }

                /*
                 * Check for wording issues in title.
                 *
                 * */

                foreach (var word in dubiousTitleWords)
                {
                    if (title.ContainsText(word))
                    {
                        validationRecord.Status = ValidationStatus.DubiousTitle;
                        validationRecord.Summary = $"Title contains text '{word}'";
                        return validationRecord;
                    }
                }
                foreach (var pattern in dubiousTitlePatterns.Keys)
                {
                    if (dubiousTitlePatterns[pattern].IsMatch(title))
                    {
                        validationRecord.Status = ValidationStatus.DubiousTitle;
                        validationRecord.Summary = $"Title matches pattern '{pattern}'";
                        return validationRecord;
                    }
                }

                validationRecord.Status = ValidationStatus.Success;
                validationRecord.Summary = "All good";
                return validationRecord;
            } // queryReader.Read

            return ValidationRecord.NoMatch;
        }

        #endregion

        #region Notification

        public const string EmailSubjectFailure = "IP Config Validation Result: failure";
        public const string EmailSubjectSuccess = "IP Config Validation Result: success";
        public const string EmailBodySuccess = "No invalid IP ranges found.";

        private void SendEmailNotification()
        {
            if (ShouldSendEmailNotfication)
            {
                string subject;
                string body;

                if (Output.Any())
                {
                    subject = EmailSubjectFailure;
                    body = EmailHelperMethods.GetHtmlTableForCollection(Output);
                }
                else
                {
                    subject = EmailSubjectSuccess;
                    body = EmailBodySuccess;
                }

                var client = runtime.HostServices
                            .GetService(typeof(IEmailClient)) as IEmailClient ?? new EmailClient();
                try
                {
                    var toAddress = new MailAddressCollection { RecipientEmailAddresses };

                    client.SendMail(
                        workflowRuntime: runtime,
                        toAddresses: toAddress,
                        subject: subject,
                        htmlContent: body);
                }
                catch (Exception ex)
                {
                    runtime.Logger.LogWarning(
                        $@"Failed to send email notification.
                        Subject: {subject}
                        Body: {body}
                        Exception: {ex}");
                }
            }
        }

        #endregion
    }
}
