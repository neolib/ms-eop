﻿// ---------------------------------------------------------------------------
// <copyright file="HelloWorkflow.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
// ---------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Microsoft.Office.Datacenter.Networking.EopWorkflows.F5Deployment
{
    using Microsoft.Office.Datacenter.CentralAdmin.Interop;

    public sealed class HelloWorkflow : Workflow<string>
    {
        [DataMember]
        public string Name { get; set; }

        private string output;

        public override string Output => output;

        private IWorkflowRuntime cachedRuntime;

        private List<string> list = new List<string>();

        protected override Continuation DoWork(IWorkflowRuntime runtime)
        {
            cachedRuntime = runtime;

            list.Add(Name);
            output = $"Hello {Name ?? "Nobody"}";

            return Continuation.Default;
        }
    }
}
