﻿// ---------------------------------------------------------------------------
// <copyright file="IPTagFinder.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
// ---------------------------------------------------------------------------
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace Microsoft.Office.Datacenter.Networking.EopWorkflows.F5Deployment
{
    /// <summary>
    /// A helper class that isolates the work of finding
    /// all tags that may contain valid IPv4/IPv6 strings.
    /// </summary>
    /// <remarks>
    /// Returned XDocument may contain duplicate IP strings. An attribute
    /// may contain a serial IP strings separated by whiespace or comma.
    ///
    /// An instance of this class can be reused.
    /// </remarks>
    public class IPTagFinder
    {
        public const string IPv4Pattern = @"(\d+\.\d+\.\d+\.\d+)";
        public const string IPv4RangePattern = @"(\d+\.\d+\.\d+\.\d+/\d+)";
        public const string IPv6Pattern = @"([1-9a-f][\da-f]*)(:([\da-f]+)*)+";
        public const string IPv6RangePattern = @"([1-9a-f][\da-f]*)(:([\da-f]+)*)+/\d+";
        public const string SeparatorPattern = @"\s*(,|\s)\s*";

        public static Regex IPv4Regex = new Regex(
            $@"^{IPv4Pattern}({SeparatorPattern}{IPv4Pattern})*$",
            RegexOptions.ExplicitCapture);

        public static Regex IPv4RangeRegex = new Regex(
            $@"^{IPv4RangePattern}({SeparatorPattern}{IPv4RangePattern})*$",
            RegexOptions.ExplicitCapture);

        public static Regex IPv6Regex = new Regex(
            $@"^{IPv6Pattern}({SeparatorPattern}{IPv6Pattern})*$",
            RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture);

        public static Regex IPv6RangeRegex = new Regex(
            $@"^{IPv6RangePattern}({SeparatorPattern}{IPv6RangePattern})*$",
            RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture);

        public static Regex VlanRegex = new Regex(
            $@"^\s*(?<no>\d+)\s+(?<name>\w+)\s+(?<v4>{IPv4RangePattern})(\s+(?<v6>{IPv6RangePattern}))?\s*$",
            RegexOptions.Multiline | RegexOptions.ExplicitCapture);

        public static Regex VlanRegex2 = new Regex(
            $@"^\s*(?<name>([a-z]+(\s+[a-z]+)?)|(\d+(/\d+)?))\s+(\-\s+)?((?<v4>({IPv4Pattern})|({IPv4RangePattern}))|(?<v6>({IPv6Pattern})|({IPv6RangePattern})))\s*$",
            RegexOptions.Multiline | RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture);

        private XDocument result;

        /// <summary>
        /// Finds all tags that contain valid IP strings.
        /// </summary>
        /// <param name="xml">F5Automation config XML.</param>
        /// <returns>An XDocument object.</returns>
        /// <remarks>
        /// The returned XDocument has the following structure:
        ///     <result>
        ///         <TAG ATTRIBUTE="IP_STRING" />
        ///     </result>
        /// where capitalized words are placeholders.
        /// </remarks>
        internal XDocument Find(string xml)
        {
            var xd = XDocument.Parse(xml);
            result = new XDocument();
            result.Add(new XElement("result"));
            WalkNode(xd.Root);
            return result;
        }

        /// <summary>
        /// Recursively walks an XElement.
        /// </summary>
        /// <param name="node">The XElement to walk.</param>
        private void WalkNode(XElement node)
        {
            var list = ExamineNode(node);
            if (list.Count > 0)
            {
                var newNode = new XElement(node.Name);
                result.Root.Add(newNode);
                foreach (var attr in list)
                {
                    newNode.Add(new XAttribute(attr.Name, attr.Value));
                }
            }
            foreach (var child in node.Elements()) { WalkNode(child); }
        }

        /// <summary>
        /// Examines an XElement for possible IP attribute values.
        /// </summary>
        /// <param name="node">The XElement object.</param>
        /// <returns>A list of XAttribute that contain IP strings.</returns>
        private List<XAttribute> ExamineNode(XElement node)
        {
            var list = new List<XAttribute>();
            foreach (var attr in node.Attributes())
            {
                // Skip this huge node!
                if (attr.Name.LocalName == "f5_class" &&
                    attr.Value == "GTM_AAAA_RECORD_CREATE_BULK")
                {
                    break;
                }

                if (ValidateValue(attr)) { list.Add(attr); }
            }
            return list;
        }

        /// <summary>
        /// Validates vlaue of an XAttribute to verify if it contains valid IP strings.
        /// </summary>
        /// <param name="attr">The XAttribute object.</param>
        /// <returns>Boolean value.</returns>
        bool ValidateValue(XAttribute attr)
        {
            var s = attr.Value;

            // Skip these special IP ranges
            if (s.StartsWith("0.0.0.0")) { return false; }
            if (s.StartsWith("255.255.255.255")) { return false; }
            if (s.StartsWith("ffff:ffff:")) { return false; }
            if (s.StartsWith("0:")) { return false; }

            if (IPv4Regex.IsMatch(s)) { return true; }
            if (IPv6Regex.IsMatch(s)) { return true; }
            if (IPv4RangeRegex.IsMatch(s)) { return true; }
            if (IPv6RangeRegex.IsMatch(s)) { return true; }

            return false;
        }
    }
}
