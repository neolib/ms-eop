﻿// ---------------------------------------------------------------------------
// <copyright file="IPConfigValidatorWorkflowTests.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
// ---------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;

namespace Microsoft.Office.Datacenter.Networking.EopWorkflows.UnitTests.F5Deployment
{
    #region Local Usings

    using CentralAdmin.Workflow.TestFramework;
    using Microsoft.Office.Datacenter.CentralAdmin.Interop;
    using Microsoft.Office.Datacenter.Networking.EopWorkflows.F5Deployment;
    using Microsoft.Office.Datacenter.Networking.KustoFactory;
    using Microsoft.Office.Datacenter.Networking.KustoFactory.UnitTests;
    using Microsoft.Office.Datacenter.Networking.Workflows.Shared.Email;
    using VisualStudio.TestTools.UnitTesting;
    using Workflows.UnitTests;
    using Workflows.UnitTests.Inventories;

    #endregion

    [TestClass]
    public sealed class IPConfigValidatorWorkflowTests
    {
        #region Inner Classes

        private class TestKustoQueryResult
        {
            [KustoField(Name = "Id")]
            internal string Id { get; set; }

            [KustoField(Name = "Prefix")]
            internal string Prefix { get; set; }

            [KustoField(Name = "Title")]
            internal string Title { get; set; }

            [KustoField(Name = "DataCenter")]
            internal string DataCenter { get; set; }
        }

        private class MockedEmailClient : IEmailClient
        {
            internal string SavedSubject { get; private set; }
            internal string SavedHtmlContent { get; private set; }

            public void SendMail(
                IWorkflowRuntime workflowRuntime,
                ICollection<MailAddress> toAddresses,
                string subject,
                string htmlContent,
                IList<Attachment> attachments = null,
                MailPriority priority = MailPriority.Normal,
                ICollection<MailAddress> ccAddresses = null)
            {
                SavedSubject = subject;
                SavedHtmlContent = htmlContent;
            }

            public void SendMailWithConstantCredentials(
                IWorkflowRuntime workflowRuntime,
                ICollection<MailAddress> toAddresses,
                string subject,
                string htmlContent,
                IList<Attachment> attachments = null,
                MailPriority priority = MailPriority.Normal,
                ICollection<MailAddress> ccAddresses = null)
            {
                throw new NotImplementedException();
            }
        }

        #endregion

        #region Variables

        // These IP strings are taken from TestEnvName.xml.
        private static string[] testIPStrings = new[]
        {
            "25.152.106.5",         // 0
            "25.152.106.6",         // 1
            "2a01:111:e400:7f55::", // 2
            "2a01:111:e400:7f55",   // 3
            "25.152.106.61",        // 4
            "25.152.106.62",        // 5
            "25.152.106.63",        // 6
            "25.152.106.64"         // 7
        };

        private List<object> testQueryResults;
        private MockedKustoCslQueryProvider mockedKustoCslQueryProvider;
        private MockedEmailClient mockedEmailClient;

        #endregion

        #region Helper Methods

        private void BuildKustoCslQueryProvider()
        {
            testQueryResults = new List<object>();
            for (int i = 0; i < testIPStrings.Length; i++)
            {
                testQueryResults.Add(new TestKustoQueryResult
                {
                    Id = "TestResult" + i,
                    Prefix = testIPStrings[i],
                    Title = ((i % 2) == 0) ? "testenvname ABC-XYZ" : "TESTENVNAME DEF-IJK",
                    DataCenter = "TESTENVNAME"
                });
            }

            mockedKustoCslQueryProvider = new MockedKustoCslQueryProvider
            {
                DefaultDatabaseName = "IpamReport",
                Data = new Dictionary<string, List<object>>
                {
                    {
                        "IpamReport",
                        testQueryResults
                    }
                }
            };
            var workflowType = typeof(IPConfigValidatorWorkflow);
            var queryTemplate = ExtensionMethods.LoadResourceText(
                workflowType.Assembly,
                workflowType.Namespace + "." + IPConfigValidatorWorkflow.QueryFileName);

            for (int i = 0; i < testIPStrings.Length; i++)
            {
                foreach (var tableName in IPConfigValidatorWorkflow.KustoDataTableNames)
                {
                    var ipVersion = testIPStrings[i].Contains(':') ? "6" : "4";
                    var query = queryTemplate
                        .Replace("{TableName}", tableName)
                        .Replace("{IpString}", testIPStrings[i])
                        .Replace("{IpVersion}", ipVersion);
                    mockedKustoCslQueryProvider.Operations.Add(
                        query,
                        items_ => items_.Cast<TestKustoQueryResult>()
                            .Where(item_ => item_.Id == "TestResult" + i));
                }
            }
        }

        private TestWorkflowManager BuildWorkflowManager()
        {
            var oneRackInventory = new OneRackInventory(new InventoryInMemoryClient());
            var testWorkflowManager = new TestWorkflowManager(oneRackInventory.Client);
            mockedEmailClient = new MockedEmailClient();
            BuildKustoCslQueryProvider();

            testWorkflowManager.AddService(typeof(IEmailClient), mockedEmailClient);
            testWorkflowManager.AddService(typeof(ICslQueryProvider), mockedKustoCslQueryProvider);

            return testWorkflowManager;
        }

        #endregion

        #region Testcases

        [TestMethod]
        public void TestAllGood()
        {
            var workflowManager = BuildWorkflowManager();

            var workflow = new IPConfigValidatorWorkflow { TestAssembly = this.GetType().Assembly };

            workflowManager.AssertWorkflowSuccess(workflow, TimeSpan.FromSeconds(30));
            Assert.IsFalse(workflow.Output.Any());

            var body = mockedEmailClient.SavedHtmlContent;
            Assert.AreEqual(mockedEmailClient.SavedSubject, IPConfigValidatorWorkflow.EmailSubjectSuccess);
            Assert.IsTrue(body.Contains(IPConfigValidatorWorkflow.EmailBodySuccess));
        }

        [TestMethod]
        public void TestMissingInAll()
        {
            var workflowManager = BuildWorkflowManager();

            // Let's do something bad...
            testQueryResults.RemoveAt(0);
            testQueryResults.RemoveAt(testQueryResults.Count - 1);

            var workflow = new IPConfigValidatorWorkflow { TestAssembly = this.GetType().Assembly };

            workflowManager.AssertWorkflowSuccess(workflow, TimeSpan.FromSeconds(30));
            Assert.AreEqual(workflow.Output.Count, 2);

            var body = mockedEmailClient.SavedHtmlContent;
            Assert.AreEqual(mockedEmailClient.SavedSubject, IPConfigValidatorWorkflow.EmailSubjectFailure);
            Assert.IsFalse(body.Contains(IPConfigValidatorWorkflow.EmailBodySuccess));
            Assert.IsTrue(body.Contains("25.152.106.5"));
            Assert.IsTrue(body.Contains("25.152.106.64"));
            Assert.IsTrue(body.Contains("NoMatch"));
        }

        public void TestMissingInDefaultButStillGood()
        {
            var workflowManager = BuildWorkflowManager();

            // Let's do something bad...
            var key = mockedKustoCslQueryProvider.Operations.Keys.First((key_) =>
                key_.StartsWith("Allocations_Default"));
            mockedKustoCslQueryProvider.Operations.Remove(key);

            var workflow = new IPConfigValidatorWorkflow { TestAssembly = this.GetType().Assembly };

            workflowManager.AssertWorkflowSuccess(workflow, TimeSpan.FromSeconds(30));
            Assert.IsFalse(workflow.Output.Any());

            var body = mockedEmailClient.SavedHtmlContent;
            Assert.AreEqual(mockedEmailClient.SavedSubject, IPConfigValidatorWorkflow.EmailSubjectSuccess);
            Assert.IsTrue(body.Contains(IPConfigValidatorWorkflow.EmailBodySuccess));
        }

        [TestMethod]
        public void TestBadTitles()
        {
            var workflowManager = BuildWorkflowManager();

            // Let's do something bad...
            ((TestKustoQueryResult)testQueryResults[1]).Title = null;
            ((TestKustoQueryResult)testQueryResults[2]).Title = "\t ";
            ((TestKustoQueryResult)testQueryResults[6]).Title = "bad title";

            var workflow = new IPConfigValidatorWorkflow { TestAssembly = this.GetType().Assembly };

            workflowManager.AssertWorkflowSuccess(workflow, TimeSpan.FromSeconds(30));
            Assert.AreEqual(workflow.Output.Count, 3);

            var body = mockedEmailClient.SavedHtmlContent;
            Assert.AreEqual(mockedEmailClient.SavedSubject, IPConfigValidatorWorkflow.EmailSubjectFailure);
            Assert.IsFalse(body.Contains(IPConfigValidatorWorkflow.EmailBodySuccess));
            Assert.IsTrue(body.Contains("25.152.106.5"));
            Assert.IsTrue(body.Contains("2a01:111:e400:7f55::"));
            Assert.IsTrue(body.Contains("25.152.106.63"));
            Assert.IsTrue(body.Contains("EmptyTitle"));
            Assert.IsTrue(body.Contains("InvalidTitle"));
        }

        #endregion
    }
}
