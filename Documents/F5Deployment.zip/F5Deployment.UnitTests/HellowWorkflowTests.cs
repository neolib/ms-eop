﻿using Microsoft.Office.Datacenter.Networking.EopWorkflows.F5Deployment;
using Microsoft.Office.Datacenter.Networking.Workflows.UnitTests;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Microsoft.Office.Datacenter.Networking.EopWorkflows.UnitTests.F5Deployment
{
    [TestClass]
    public sealed class HellowWorkflowTests
    {
        [TestMethod]
        public void TestWorkflow()
        {
            var workflow = new HelloWorkflow();
            var tm = new TestWorkflowManager();

            workflow.Name = "John";
            var output = tm.AssertFunctionWorkflowSuccess(workflow, TimeSpan.FromSeconds(30));

        }
    }
}
