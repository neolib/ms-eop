﻿// ---------------------------------------------------------------------------
// <copyright file="IPConfigValidatorWorkflowTests.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
// ---------------------------------------------------------------------------
using System.Linq;

namespace Microsoft.Office.Datacenter.Networking.EopWorkflows.UnitTests.F5Deployment
{
    #region Local Usings

    using Microsoft.Office.Datacenter.Networking.EopWorkflows.F5Deployment;
    using VisualStudio.TestTools.UnitTesting;

    #endregion

    [TestClass]
    public sealed class IPTagFinderTests
    {
        /// <summary>
        /// Tests if IPTagFinder works in overall.
        /// </summary>
        /// <remarks>
        /// Also tests F5DeploymentHelpers.LoadResourceText along the way.
        /// </remarks>
        [TestMethod]
        public void TestIPTagFinder()
        {
            var finder = new IPTagFinder();
            var myType = this.GetType();
            var xml = ExtensionMethods.LoadResourceText(
                myType.Assembly,
                myType.Namespace + ".TestEnvName.xml");

            var xd = finder.Find(xml);
            var objects = xd.Root.Elements("object").ToArray();
            var tests = xd.Root.Elements("TESTTAG").ToArray();
            Assert.AreEqual(objects.Count(), 2);
            Assert.AreEqual(tests.Count(), 1);

            var object1 = objects[0];
            Assert.AreEqual(object1.Attributes().Count(), 3);

            var object2 = objects[1];
            Assert.AreEqual(object2.Attributes().Count(), 3);
            Assert.IsTrue(object2.Attribute("LDAP_AD_IP_ADDRESSES").Value.Contains(" "));

            var test = tests[0];
            Assert.AreEqual(test.Attributes().Count(), 1);
            Assert.IsTrue(test.Attributes().First().Value.Contains(","));
        }
    }
}
